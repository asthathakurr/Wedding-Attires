const ProfileFavourit: React.FC = () => {
  return (
    <div>
      <h2>Favourite Products</h2>
      <p>coming soon</p>
    </div>
  );
};

export default ProfileFavourit;
